
----Step 1  SCRULES..DimUserInstanceLevel

		--DELETE FROM ilev

		----SELECT fkey.BillingSubSystemId, ilev.*
		--FROM SCRULES..DimUserInstanceLevel ilev

		--INNER JOIN SCRULES..DimUserFactInstance inst
		--ON  inst.UserKey = ilev.UserKey
		
		--INNER JOIN SCRULES..DIMUserFactKey fkey
		--ON  fkey.UserFactkey = inst.UserFactKey
		
		--WHERE inst.DimensionKey = 7


--Step 2  SCRULES..DIMUserFactInstance

		--DELETE FROM inst
		----SELECT fkey.BillingSubSystemId, inst.*
		--FROM SCRULES..DIMUserFactInstance inst
		
		--INNER JOIN SCRULES..DIMUserFactKey fkey
		--ON  fkey.UserFactkey = inst.UserFactKey
		
		--	WHERE inst.DimensionKey = 7


        
--Step 3  SCRULES..DIMUserFactKey

  --      DELETE FROM fact
  --      --SELECT fact.* 
  --      FROM  SCRULES..DIMUserFactKey fact

  --      LEFT OUTER JOIN SCRULES..DimUserFactInstance inst
		--ON  inst.UserFactKey = fact.UserFactKey

  --      WHERE fact.DimensionId = 7
  --        AND inst.LongName is null
  
--Step 4 SCRULES..DimUserLevelParent

        --DELETE FROM par
		----SELECT par.*
		--FROM SCRules..DimUserLevelParent par
		--where par.DimensionKey = 7
		

 
--Step 5 SCRULES..DimUserLevel

        --DELETE FROM lev
		----SELECT lev.*
		--FROM SCRules..DimUserLevel lev
		--where lev.DimensionId = 7

