		--step 1 check for outlier codes
		SELECT fkey.*, 'Next', inst.*
		FROM SCRULES..DIMUserFactInstance inst
		
		INNER JOIN SCRULES..DIMUserFactKey fkey
		ON  fkey.UserFactkey = inst.UserFactKey
		
			WHERE inst.DimensionKey = 7
			  AND inst.LONGNAME = 'New Region Code';


		--step 2, check if any codes are mapped to unmapped level
		SELECT fkey.BillingSubSystemId, ilev.*
		FROM SCRULES..DimUserInstanceLevel ilev

		INNER JOIN SCRULES..DimUserFactInstance inst
		ON  inst.UserKey = ilev.UserKey
		
		INNER JOIN SCRULES..DIMUserFactKey fkey
		ON  fkey.UserFactkey = inst.UserFactKey
		
		WHERE inst.DimensionKey = 7
		  AND inst.LONGNAME = 'New Region Code';
		  
